package logic;

import java.util.Objects;

public class StockTradeEntity {
    private int id;
    private String name;
    private double priceStock;


    public StockTradeEntity(int id, String name, double priceStock) {
        this.id = id;
        this.priceStock = priceStock;
        this.name = name;
    }

    public StockTradeEntity(){

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPriceStock() {
        return priceStock;
    }

    public void setPriceStock(double priceStock) {
        this.priceStock = priceStock;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof StockTradeEntity)) return false;
        StockTradeEntity that = (StockTradeEntity) o;
        return getId() == that.getId() && Double.compare(that.getPriceStock(), getPriceStock()) == 0 && Objects.equals(getName(), that.getName());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getName(), getPriceStock());
    }

    @Override
    public String toString() {
        return "StockTradeEntity{" + "id=" + id + ", name='" + name + '\'' + ", priceStock=" + priceStock + '}';
    }
}
