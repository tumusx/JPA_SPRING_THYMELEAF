package logic;

public class BuyAgent {
    private int price;

    public BuyAgent(int price) {
        this.price = price;
    }

    public void comprarAcao(int price) {
        this.price = price;
        if ((price % 2) != 0) {
            System.out.println("Comprado");
        }
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
}
