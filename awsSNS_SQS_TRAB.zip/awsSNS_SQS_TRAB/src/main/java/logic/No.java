package logic;

public class No {
    StockTradeEntity stockTradeEntity;
    No next;
}
