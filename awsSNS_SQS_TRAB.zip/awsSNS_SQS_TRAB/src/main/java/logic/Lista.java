package logic;

public class Lista {
    No inicio;
    int tamanho;

    public void inserir(StockTradeEntity info) {
        No no = new No();
        no.stockTradeEntity = info;
        no.next = inicio;
        inicio = no;
        tamanho++;
    }


    public String toString() {
        String out = "";
        No no = inicio;
        while (no != null) {
            out += no.stockTradeEntity + " ";
            no = no.next;
        }
        return out;
    }
}
