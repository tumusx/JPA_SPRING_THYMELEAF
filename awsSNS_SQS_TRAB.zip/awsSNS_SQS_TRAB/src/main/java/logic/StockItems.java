package logic;

import java.util.ArrayList;
import java.util.List;

public class StockItems {

    public static final List<HashTable> ITEMS = new  ArrayList<HashTable>();

    public static void addStocke(List<HashTable> items){
        ITEMS.addAll(items);
    }

}
