package logic;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicSessionCredentials;
import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSClient;
import com.amazonaws.services.sqs.model.Message;
import org.json.JSONObject;

import java.util.List;

public class StockSubscriber {

	public static void main(String[] args) {
	
		String fifoURL = "https://sqs.us-east-1.amazonaws.com/154982821863/order-queque-sisd-trab";
		
		BasicSessionCredentials awsCreds = new BasicSessionCredentials("ASIASIFNSF7TXA6YD6LJ", "wSLJAjn1ygIBXoZZA4coQjaKPCaoAWL2efcNEUx1", "FwoGZXIvYXdzENr//////////wEaDKdTnGtSRuQVGQKmtSLTAUrRqXgIuXbmc0xnqH2tnez0Q4o7Pmo6WAOxlmD9yhp3XqxdEhBq1uMJiS3m375qKNWQBWAzr2faSORUY+JHion2p0YmRKLkOtMApxe5je7N4a5Z6ab3cnNB/JvnapjBD5adJj9Bhz/2K8fCVEW2tx544Via6ygedX6GfEXLbwU/YZiTvSlLB8qEiTm53/pS9TFbHyOB1nMbIGcXPjjOVIKPeZcyCLQ+FUHCIcrxk31WV+7j0qu4zvxbojtAtCc1K4RcPA8T+1R1yVjiK8K63AuvDUso8ZXplQYyLSfvhCVEhb9+1y3zkWuqFDnxtIhumUo/xo6S8RO0OWoHFGQ8R9GVDEA7ZwbZRw==");
		
		AmazonSQS sqs = AmazonSQSClient.builder().withRegion("us-east-1") .withCredentials(new AWSStaticCredentialsProvider(awsCreds)).build();

		while (true) {

			System.out.println(StockItems.ITEMS);
			
			List<Message> messages = sqs.receiveMessage(fifoURL).getMessages();

			for (Message m : messages) {

				sqs.deleteMessage(fifoURL, m.getReceiptHandle());
				
				System.out.println("Recebeu acao " + m.getMessageId());
				
				String body = m.getBody();
				
				JSONObject json = new JSONObject(body);

				Object num = json.get("num");
				
				
			}
		}
	}

	public void venderAcao(StockTradeEntity ste){
		
		int aux = ste.getId();
		
		if((aux % 2) == 0) {
			System.out.println("Vendido");
		}
		
		if((aux % 2) != 0) {
			System.out.println("Comprado");
		}
		
	}
	
}
