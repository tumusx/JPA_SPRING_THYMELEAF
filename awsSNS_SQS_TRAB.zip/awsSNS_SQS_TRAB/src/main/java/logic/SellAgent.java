package logic;

public class SellAgent {
    private int price;

    public SellAgent(int price){
        this.price = price;
    }

    public void venderAcao(int price){
        this.price = price;
        if((price % 2) == 0) {
            System.out.println("Vendido");
        }
    }
    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
}
