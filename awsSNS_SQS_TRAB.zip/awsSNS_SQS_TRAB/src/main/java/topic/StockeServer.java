package topic;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicSessionCredentials;
import com.amazonaws.services.sns.AmazonSNSClient;
import com.amazonaws.services.sns.model.PublishResult;
import logic.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;


public class StockeServer {

	public static void main(String[] args) {

        BasicSessionCredentials awsCreds = new BasicSessionCredentials("ASIASIFNSF7TRBB7IVWK", "mg3n90CjG+mKA+zeiUoD7Anah1HSxr6tYOLGE3ow", "FwoGZXIvYXdzEEgaDAVoiLwwFgQNZ1Yj+iLTAcGurfJrSJDQ2UPSiynKyflUn2W+TQ3acrzRIyEepg62R4yMiQbIWCBvBWniYpTXRp0fAfsfhfCkzVREC4Xhw7a4Tab+dCGRaiyg6bVPyE8Slz9uJEIv+lqWQbg7nchhxTeW/XWrnd7gIFaAv6ln7INiLYvVd+HQ+HwnV+2/ZXIdG1F5gtdgwo4O6PHPp4zkbRCQRHlMW3CW8uO75zJ48Eg0iAuiQ4sR/Ddgv/Jxys/+1icIj1r/JtJvIGRgIGndPvFuarjulRAhHiZnstHwVVwzhnMojrmBlgYyLa6mQNhZjbcpAWP9NhUC2QDyRb69jFqkC1a/l/xUHkrHx7grPCu4UWuEP8W9Qw==");

        AmazonSNSClient snsClient1 = (AmazonSNSClient) AmazonSNSClient.builder().withRegion("us-east-1").withCredentials(new AWSStaticCredentialsProvider(awsCreds)).build();

        int orderNum = 1;

        Random random = new Random();

        while (true) {
        	long time = random.nextInt(5000);

        	try {
                Thread.sleep(time);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            HashTable hash = new HashTable(orderNum);

            hash.inserir( new StockTradeEntity(orderNum, "SaveStockTok", orderNum));
            List<HashTable> hashTableList = new ArrayList<HashTable>();

           if((orderNum % 2) == 0){
               PublishResult snsSend = snsClient1.publish("arn:aws:sns:us-east-1:154982821863:stockMarket",  hash.toString());
               System.out.println("ACAO: " +  snsSend +  hash + ". Message ID: " + snsSend.getMessageId());
               System.out.println("\n");
           }else{
               PublishResult snsSend = snsClient1.publish("arn:aws:sns:us-east-1:154982821863:stockMarket",  hash.toString());
               System.out.println("ACAO: " +  snsSend +  hash + ". Message ID: " + snsSend.getMessageId());
               System.out.println("\n");
           }

            orderNum++;

            hashTableList.add(hash);
            StockItems.addStocke(hashTableList);
        }
    }
}
