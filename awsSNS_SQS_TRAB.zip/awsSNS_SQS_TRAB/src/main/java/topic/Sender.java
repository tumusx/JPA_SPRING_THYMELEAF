package topic;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicSessionCredentials;
import com.amazonaws.services.sns.AmazonSNSClient;
import com.amazonaws.services.sns.model.PublishResult;
import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSClient;
import com.amazonaws.services.sqs.model.Message;
import logic.BuyAgent;
import logic.HashTable;
import logic.SellAgent;
import logic.StockTradeEntity;

import java.util.ArrayList;
import java.util.List;


public class Sender {

    public static void main(String[] args) {

        String queueUrl = "https://sqs.us-east-1.amazonaws.com/154982821863/order-queque-sisd-trab"; //fila MARKET

        BasicSessionCredentials awsCreds = new BasicSessionCredentials("ASIASIFNSF7TRBB7IVWK", "mg3n90CjG+mKA+zeiUoD7Anah1HSxr6tYOLGE3ow",
                "FwoGZXIvYXdzEEgaDAVoiLwwFgQNZ1Yj+iLTAcGurfJrSJDQ2UPSiynKyflUn2W+TQ3acrzRIyEepg62R4yMiQbIWCBvBWniYpTXRp0fAfsfhfCkzVREC4Xhw7a4Tab+dCGRaiyg6bVPyE8Slz9uJEIv+lqWQbg7nchhxTeW/XWrnd7gIFaAv6ln7INiLYvVd+HQ+HwnV+2/ZXIdG1F5gtdgwo4O6PHPp4zkbRCQRHlMW3CW8uO75zJ48Eg0iAuiQ4sR/Ddgv/Jxys/+1icIj1r/JtJvIGRgIGndPvFuarjulRAhHiZnstHwVVwzhnMojrmBlgYyLa6mQNhZjbcpAWP9NhUC2QDyRb69jFqkC1a/l/xUHkrHx7grPCu4UWuEP8W9Qw==");
        AmazonSNSClient snsClient1 = (AmazonSNSClient) AmazonSNSClient.builder().withRegion("us-east-1").withCredentials(new AWSStaticCredentialsProvider(awsCreds)).build();
        AmazonSQS sqs = AmazonSQSClient.builder().withRegion("us-east-1").withCredentials(new AWSStaticCredentialsProvider(awsCreds)).build();
        int orderNum = 1;
        SellAgent sellAgent = new SellAgent(orderNum);
        BuyAgent buyAgent = new BuyAgent(orderNum);

        while (true) {
            HashTable hash = new HashTable(orderNum);

            hash.inserir( new StockTradeEntity(orderNum, "SaveStockTok", orderNum));
            List<HashTable> hashTableList = new ArrayList<HashTable>();

            List<Message> messages = sqs.receiveMessage(queueUrl).getMessages();
            for (Message m : messages) {
                sqs.deleteMessage(queueUrl, m.getReceiptHandle());
                System.out.println("Recebeu " + m.getMessageId());
            }
            if ((orderNum % 2) == 0) {
                PublishResult snsSend = snsClient1.publish("arn:aws:sns:us-east-1:154982821863:stockMarket", hash + "vendido");
                sellAgent.venderAcao(orderNum);
            } else {
                PublishResult snsSend = snsClient1.publish("arn:aws:sns:us-east-1:154982821863:stockMarket", hash + "comprado");
                buyAgent.comprarAcao(orderNum);
            }
            orderNum++;
        }
    }
}

